[[_ErrorDocumentContainsExtractableText_n.d.]]

# [ERROR: Document contains no extractable text WITH Parniske_-_2008_-_Arbuscular_mycorrhizae_the_motehr_of_plant_root_endosymbioses-annotated.pdf]()

## [[]]

### n.d.## Quote
> 

