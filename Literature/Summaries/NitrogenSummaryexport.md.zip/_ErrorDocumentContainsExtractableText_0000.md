[[_ErrorDocumentContainsExtractableText_n.d.]]

# [ERROR: Document contains no extractable text WITH ossler_et_al_2015_tripartite_mutualism_-_facilitation_or_trade-offs_between_rhizobial_and.pdf]()

## [[]]

### n.d.## Quote
> 

